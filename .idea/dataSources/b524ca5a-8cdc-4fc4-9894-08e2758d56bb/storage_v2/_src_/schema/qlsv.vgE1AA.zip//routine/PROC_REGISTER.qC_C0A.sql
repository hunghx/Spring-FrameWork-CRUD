create
    definer = root@localhost procedure PROC_REGISTER(IN user varchar(255), IN pass varchar(100))
begin
    INSERT INTO Accounts(username, password) value (user,pass);
end;

