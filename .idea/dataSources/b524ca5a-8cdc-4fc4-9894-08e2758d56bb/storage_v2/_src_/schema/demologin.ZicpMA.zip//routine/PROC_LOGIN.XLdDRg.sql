create
    definer = root@localhost procedure PROC_LOGIN(IN user varchar(255), IN pass varchar(100))
begin
    SELECT * from Accounts where username like user and password like pass;
end;

