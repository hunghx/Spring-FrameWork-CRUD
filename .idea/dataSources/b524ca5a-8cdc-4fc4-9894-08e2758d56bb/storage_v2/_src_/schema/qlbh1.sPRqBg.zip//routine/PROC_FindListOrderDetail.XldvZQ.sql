create
    definer = root@localhost procedure PROC_FindListOrderDetail(IN orderId int)
begin
    select  od.*,p.name,p.image_url,p.description from OrderDetail od join product p on p.id = od.product_id where order_id = orderId;
end;

