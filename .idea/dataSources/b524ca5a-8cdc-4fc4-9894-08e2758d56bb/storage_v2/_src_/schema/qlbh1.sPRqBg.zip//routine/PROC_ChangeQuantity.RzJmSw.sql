create
    definer = root@localhost procedure PROC_ChangeQuantity(IN idUp int, IN quantityUp int)
begin
    update OrderDetail set quantity=quantityUp where id=idUp;
end;

